import pygame
import time

"""
pygame.Rect(x, y, width, height)

my_new_rect = myrect.Rect.copy() --> copier un rectangle
Rect.move() |
Rect.move_ip()    : modifie les coordoneées comme fait la
                    ( myrect.x += 1, myrect.y += 1)
                    
Rect.inflate()    : agransir le rectangle ou le reduire avec des valeurs negatifs

Rect.colliderect()  :Collision
    
"""



window_resolution = (640, 480)
blue_color = (0, 75, 255)
black_color = (0, 0, 0)
red = (255, 0, 0)
i = 0

pygame.init()
    # titre
pygame.display.set_caption("L' objet Rect")
window_surface = pygame.display.set_mode(window_resolution) # surface


myrect = pygame.Rect(10, 100, 25, 25)
myblock = pygame.Rect(600, 50, 20, 300)
pygame.draw.rect(window_surface, red, myrect)
pygame.draw.rect(window_surface, blue_color, myblock)
pygame.display.flip()













launched = True


while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False

    while myrect.colliderect(myblock) == False:
        time.sleep(.010)
        # remetre la surface en noir
        window_surface.fill(black_color)
        # recuperer x et y et les augmentés de 1
        #myrect.x += 1
        #myrect.y += 0

        pygame.Rect.move_ip(myrect, 1, 0)

        # redessine le rectangle
        pygame.draw.rect(window_surface, red, myrect)
        pygame.draw.rect(window_surface, blue_color, myblock)
        pygame.display.flip()



















