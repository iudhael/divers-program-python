import pygame

"""
arial_font.set_bold()
arial_font.set_italic()
arial_font.set_underline()
"""


window_resolution = (640, 480)
blank = (255, 255, 255)
black_color = (0, 0, 0)

pygame.init()
    # titre
pygame.display.set_caption("Afficher du texte")
window_surface = pygame.display.set_mode(window_resolution) # surface



# chaeger une police
# SysFont(police, taille, True(police en gras), False)
arial_font = pygame.font.SysFont("arial", 30)

# texte
# render(texte, lisser les pixel, couleur du texte, couleur de fond)
hello_text_surface = arial_font.render("hello world", False, black_color, blank)


# chaeger une police
# utiliser Font aulieu de SysFont
roboto_font = pygame.font.Font("Roboto-ThinItalic.ttf", 100)

# texte
# render(texte, lisser les pixel, couleur du texte, couleur de fond)
text_surface = roboto_font.render("world", True, blank)




window_surface.blit(hello_text_surface, [10, 10])
window_surface.blit(text_surface, [50, 50])
# mettre ajour la fenetre
pygame.display.flip()










launched = True

while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False





