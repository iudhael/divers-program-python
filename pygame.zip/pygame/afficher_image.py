import pygame





window_resolution = (800, 480)
blank_color = (255, 255, 255)
black_color = (0, 0, 0)

pygame.init()
    # titre
pygame.display.set_caption("Mon programme pygame")
window_surface = pygame.display.set_mode(window_resolution) # surface


# image jpg

bg_image = pygame.image.load("bg.jpg") # retourner une surface
# convertion du format de pixel de  l'image
bg_image.convert()
# couleur de transparence image jpg
# rendre tous les endroits blancs de l'image transparent
bg_image.set_colorkey(blank_color)


# image png
banner_image = pygame.image.load("banner.png") # retourner une surface
# convertion du format de pixel de  l'image
banner_image.convert_alpha()



launched = True

while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False



    # corps du programme
    window_surface.fill(black_color)
    window_surface.blit(bg_image, [10, 10])
    window_surface.blit(banner_image, [75, 10])



    # charger les composants
    pygame.display.flip()






















