import pygame





window_resolution = (640, 480)
blue_color = (89, 152, 255)
black_color = (0, 0, 0)

pygame.init()
    # titre
pygame.display.set_caption("Mon programme pygame")
window_surface = pygame.display.set_mode(window_resolution) # surface

# remplir la surface de la couleur
window_surface.fill(blue_color)

"""
 dessiner une ligne 
( preciser en parametre la surface, couleur, position de 
départ [ x et y ] position de fin [x et y], et l'epaisseur )

pour dessiner  un point il faut que les coordonné de départ soient identique aux coordonné 
de fin 


pygame.draw.line(window_surface, black_color, [10, 10], [100, 100], 5)


"""

# dessiner un rectangle
"""
Rect(left, top, width, height, epaisseur)

rect_form = pygame.Rect(10, 10, 150, 65)

pygame.draw.rect(window_surface, black_color, rect_form, 4)
"""


# dessiner un cercle
"""
cercle remplit :
    circle( surface, couleur, position du centre du cercle entre crochet ou 
            parenthese, diametre)
cercle non remplir il faut prciser l"epaisseur



pygame.draw.circle(window_surface, black_color, [150, 100], 50, 2)

"""

# dessiner une forme quelquonque
"""
polygon(surface, couleur, coordonnées(position de chaque point))
"""
coords = [(10, 10), (100, 10), (30, 50)]
pygame.draw.polygon(window_surface, black_color, coords, 2)





# mettre ajour la fenetre
pygame.display.flip()


launched = True

while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False




