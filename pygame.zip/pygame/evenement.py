import pygame





window_resolution = (640, 480)
while_color = (255, 255, 255)
black_color = (0, 0, 0)


pygame.init()
    # titre
pygame.display.set_caption("Evenement")
window_surface = pygame.display.set_mode(window_resolution, pygame.RESIZABLE)

arial_font = pygame.font.SysFont("arial", 30)
dimension_text = arial_font.render("{}".format(window_resolution), True, while_color)
window_surface.blit(dimension_text, [10, 10])



# mettre ajour la fenetre
pygame.display.flip()







launched = True

while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False
        elif event.type == pygame.VIDEORESIZE:

            # VIDEOrESIZE(w, h)

            window_surface.fill(black_color) # effacer l'ecrant
            # retourner la taille de l'ecrant lorsqu'elle est reduite ou agrandit
            # event.w et event.h envoyer a VIDEORESIZE()
            dimension_text = arial_font.render("{}x{}".format(event.w, event.h), True, while_color)
            window_surface.blit(dimension_text, [10, 10])
            pygame.display.flip()


        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                print("Haut")
            elif event.key == pygame.K_DOWN:
                print("Bas")
            elif event.key == pygame.K_LEFT:
                print("Gauche")
            elif event.key == pygame.K_RIGHT:
                print("Droite")
            else:
                print("Autre touche...")

        # souris de l'ecrant

        elif event.type == pygame.MOUSEMOTION:
            print("{}".format(event.pos))







