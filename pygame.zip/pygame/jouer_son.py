import pygame


# travailler avec le format .ogg ou .wav
"""
<Sound>.play(loop = 0, time = 0, fadein = 0)
    loop --> repetition de la musique, par defaut = 0
    time --> temps maximum jusqu'ou le son sera jouer
    fadein --> fondu d'ouverture : gestion du volume a l'ouverture du fichier son
                si on met 20000 if faudra 2 second pour que le volume aille a 100

<Sound>.stop()
        .fadeout(ms) : reduit le volume du son vers la fin du son
        .set_volume(0.0 -> 1.0) 0.0 : son de 0 % 1.0 son de 100%
        .get_volume()   : recuperer le volume
        .get_length()   : obtenir durée de la musique en seconde 



"""



window_resolution = (640, 480)
while_color = (255, 255, 255)
black_color = (0, 0, 0)


pygame.init()
    # titre
pygame.display.set_caption("Jouer son")
window_surface = pygame.display.set_mode(window_resolution, pygame.RESIZABLE)

"""
song = pygame.mixer.Sound("game_over.ogg")
song.play(1, 0, 2000)


song1 = pygame.mixer.Sound("là bas.mp3")
song1.play()

"""


# pour une play liste on a 'music' un sous module de mixer

pygame.mixer.music.load("game_over.ogg")
pygame.mixer.music.play(3, 0, 2000)



# mettre ajour la fenetre
pygame.display.flip()







launched = True

while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False

        elif event.type == pygame.KEYDOWN:
            """
            if event.key == pygame.K_s:
                #song.stop()
                # stoper toute les chassons qui passent
                pygame.mixer.stop()

            elif event.key == pygame.K_SPACE:
                # tout mettre en pause
                pygame.mixer.pause()

            elif event.key == pygame.K_p:
                # tout mettre en play
                pygame.mixer.unpause()
            """

            # pour la playliste
            if event.key == pygame.K_SPACE:
                # tout mettre en pause
                pygame.mixer.music.pause()

            elif event.key == pygame.K_p:
                # tout mettre en play
                pygame.mixer.music.unpause()

                # revenir au debut de la liste de son
            elif event.key == pygame.K_r:

                pygame.mixer.music.rewind()







