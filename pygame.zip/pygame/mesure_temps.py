import pygame







window_resolution = (640, 480)
blue_color = (132, 180, 255)
red = (255, 0, 0)
black = (0, 0, 0)


pygame.init()

clock = pygame.time.Clock()

# definir un timer pour la mise a jour du fps tous les 2 s
# declencher un USEREVENT tous les 2 s
pygame.time.set_timer(pygame.USEREVENT, 2000)




    # titre
pygame.display.set_caption("Mesure temps")
window_surface = pygame.display.set_mode(window_resolution)

arial_font = pygame.font.SysFont("arial", 30)
text = arial_font.render("Bonjour !!!", True, blue_color)
window_surface.blit(text, [50, 50])
# mettre ajour la fenetre
pygame.display.flip()

"""

# mettre en pause le processus pendant 5 seconde puis changer la couleur du texte
# time.wait(milliseconde)    1s ---> 1000milliseconde
pygame.time.wait(5000)

text = arial_font.render("Bonjour !!!", True, red)
window_surface.blit(text, [50, 50])
# mettre ajour la fenetre
pygame.display.flip()


# pour que ce soit le processeur de l'ordi qui mette en pause  on utilise 'delay'
#on fait     pygame.time.delay(5000)


"""








launched = True

while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False

        elif event.type == pygame.USEREVENT:


            # recuperer le nombre de FPS
            # print(f"{clock.get_fps()} FPS")

            window_surface.fill(black)

            """
            # module de temps propre a pygame
            # conaitre le temps ecouler depuis l'initialisatioon de pygame
            text = arial_font.render(f"Temps écouer {pygame.time.get_ticks()}", True, blue_color)
            window_surface.blit(text, [10, 10])
            pygame.display.flip()
            """

            # :.2f ----> 2 chiffre apres la virgule
            #print("%.2f" % clock.get_fps())
            #print(f"{clock.get_fps():.2f}")

            """
            text = arial_font.render(f"{clock.get_fps():.2f} FPS", True, blue_color)
            window_surface.blit(text, [50, 50])
            pygame.display.flip()
            """

    # mettre a jour le temps ecouler dès le début du processus
    #clock.tick(60)  # 60 pour un rafraichissement de 60 image par seconde ou(60 fps)
















