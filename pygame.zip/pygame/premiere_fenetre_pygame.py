import pygame

"""
pyopengl pour la 3D
"""

"""
pygame.FULLSCREEN   : plein écrant
pygame.RESIZABLE    : fenetre redimentionnable
pygame.NOFRAME      : on a une fenetre sans la croix de sortie



pygame.OPENGL
pygame.HWSURFACE    
pygame.DOUBLEBUF    : succession d'image pour creer 
                      des animations avec les images
                      
window_surface = pygame.display.set_mode(resolution, pygame.FULLSCREEN | ajouter d'autre)

"""




resolution = (640, 480)

pygame.init()
    # titre
pygame.display.set_caption("Mon programme pygame")
window_surface = pygame.display.set_mode(resolution)
# print(pygame.display.Info())



launched = True

while launched:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            launched = False



















